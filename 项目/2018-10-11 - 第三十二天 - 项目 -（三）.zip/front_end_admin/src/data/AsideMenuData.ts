export default [
    {
        "text": "首页",
        "name": "/",
        "icon": "iconfont icon-home"
    },
    {
        "text": "精选推荐",
        "name": "/recomment",
        "icon": "iconfont icon-fire"
    },
    {
        "text": "分类",
        "name": "/category",
        "icon": "iconfont icon-category"
    },
    {
        "text": "美食",
        "name": "/food",
        "icon": "iconfont icon-hotfood"
    },
    {
        "text": "菜单",
        "name": "/catemenu",
        "icon": "iconfont icon-navicon-xtcp"
    },
    {
        "text": "用户",
        "name": "/user",
        "icon": "iconfont icon-user"
    },
    {
        "text": "评论",
        "name": "/comment",
        "icon": "iconfont icon-pinglun"
    },
    {
        "text": "搜藏",
        "name": "/favorite",
        "icon": "iconfont icon-aixinsoucangshangpin"
    }
];