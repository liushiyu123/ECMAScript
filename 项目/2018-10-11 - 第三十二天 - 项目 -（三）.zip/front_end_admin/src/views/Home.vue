<template>
    <div>
        Home
    </div>
</template>

<script lang="ts">

    import { Vue, Component } from "vue-property-decorator";

    @Component
    export default class Home extends Vue {
        
    }

</script>
