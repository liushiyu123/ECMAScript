/**
 * 类型约束 : 
 */

// 如果是在js中
// function fn(x, y) {
//     return x + y;
// }

// fn(1, 2);
// fn('a', 'b');


// 函数重载
// function fn(x: number, y: number): number;
// function fn(x: string, y: string): string;

// function fn(x: any, y: any): any {
//     return x + y;
// }

// fn(1, 2);
// fn('a', 'b');
// fn(1, 'a');