let div1 = document.querySelector('div');
// 约束我们对该数据的使用
if (div1) {
    div1.style.color = 'red';
}