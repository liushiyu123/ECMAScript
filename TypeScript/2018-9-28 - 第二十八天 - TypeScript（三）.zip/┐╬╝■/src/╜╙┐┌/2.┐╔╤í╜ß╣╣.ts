// /**
//  * 如果规则中有些是可选的，那么通过 ? 标识
//  */

// interface Options {
//     width: number,
//     height: number,
//     color?: string
// }

// function fn(opts: Options) {}

// fn({
//     height: 200,
//     width: 100
// });