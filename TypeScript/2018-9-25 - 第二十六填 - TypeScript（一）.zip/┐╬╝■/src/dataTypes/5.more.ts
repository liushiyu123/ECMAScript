// let a: string|number;

// a = 'm';
// a = 1;
// a = true;


// let b: string&number;