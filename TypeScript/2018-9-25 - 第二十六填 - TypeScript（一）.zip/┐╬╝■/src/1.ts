/**
 * typescript是javascript的超集
 * teypscript完全兼容javascript代码
 */

import a from './2'

var str = 'Hello TypeScript';
console.log( str );
console.log(a);

class Person {
}