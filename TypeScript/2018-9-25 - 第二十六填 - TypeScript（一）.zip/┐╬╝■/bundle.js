define("2", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = 10;
});
/**
 * typescript是javascript的超集
 * teypscript完全兼容javascript代码
 */
define("1", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var str = 'Hello TypeScript';
    console.log(str);
});
