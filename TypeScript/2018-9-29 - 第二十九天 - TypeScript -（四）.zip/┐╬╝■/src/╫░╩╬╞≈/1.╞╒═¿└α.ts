// class Person {
//     username: string;
//     age: number;

//     constructor(username: string, age: number) {
//         this.username = username;
//         this.age = age;
//     }

//     say() {
//         console.log('say');
//     }
// }

// class Baby extends Person {
//     wawa() {
//         console.log('哇哇~~~~');
//     }
// }

// class Student extends Person {
//     study() {
//         console.log('study');
//     }
// }

// class Teacher extends Person {
//     study() {
//         console.log('study');
//     }

//     teach() {
//         console.log('teach');
//     }
// }

// class SuperMan extends Person {
//     study() {
//         console.log('study');
//     }
// }