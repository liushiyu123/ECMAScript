// // function fn<T extends HTMLElement>(a: T) {
// //     a.querySelector('div');
// // }

// interface Len {
//     length: number
// }

// function fn<T extends Len>(a: T) {
//     // 不是所有类型都有length
//     a.length
// }

// fn('1');
