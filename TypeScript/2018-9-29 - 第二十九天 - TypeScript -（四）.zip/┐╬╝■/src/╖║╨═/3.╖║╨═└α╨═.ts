


// // let fn: (x: number, y: number) => number = function(x, y) {
// //     return x + y;
// // }



// // interface IFn {
// //     (x: number, y: number): number
// // }

// // let fn: IFn = function(x, y) {
// //     return x + y;
// // }



// // 泛型类型
// // let fn: <T>(x: T, y: T) => Number = function (x, y) {
// //     return Number(x) + Number(y);
// // }




// // 泛型接口

// interface IFn <T> {
//     (x: T, y: T): number
// }

// let fn: IFn<string> = function(x, y) {
//     return Number(x) + Number(y);
// }