// // interface Person {
// //     [attr: string]: any
// // }
// class Person {

//     constructor(public username: string, public age: number) {

//     }

// }

// // // // Person => 一个拥有Person类型对应特征的对象
// // let p1: Person = new Person('Kimoo', 30);



// // function SuperMan(obj: Person) {
// //     obj.fly = function() {
// //         console.log('fly');
// //     }
// // }


// // function getPersonObj(constructor: Person) {// 我想约束传入的必须是一个构造函数
// //     // Person 表示这个类型对应的对象，我们这里要的Person的构造函数，不是他的对象
// //     // return new constructor();
// //     return new constructor();
// // }

// // getPersonObj( Person  );

// // function getArray(constructor: {new(): Array<string>}) {   // {new()} 接收一个可以产生对象的构造函数
// //     return new constructor();
// // }

// // getArray( Array  );


// // Person类的对象
// // let a: Person;
// // let fn1: {new (): Person};



// // interface Window { 
// //     [attr: string]: any
// // }


// // window.miaov = 1;
