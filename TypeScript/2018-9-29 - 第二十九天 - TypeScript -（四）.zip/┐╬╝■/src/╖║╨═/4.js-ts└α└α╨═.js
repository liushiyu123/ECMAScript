// class Person {

//     constructor(username, age) {
//         this.username = username;
//         this.age = age;
//     }
// }

// // let p1 = new Person('Kimoo', 30);

// // 接收一个具体 Person 对象
// // function SuperMan(obj) {
// //     obj.fly = function() {
// //         console.log('fly');
// //     }
// // }

// // SuperMan(p1);

// function _(constructor) {
//     return new constructor();
// }

// let arr = _(Array);
// let date = _(Date);


// // function $() {
// //     return new JQuery();
// // }

// // $()